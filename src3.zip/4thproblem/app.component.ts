import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

	users = [{name:'gowtham',age:20},{name:'surendra',age:22},{name:'Naveen',age:30}];

	
 }

